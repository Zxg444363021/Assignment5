package iss.java.mail;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
/**
 * 登陆认证类,继承Authenticator这个抽象类
 * @author zhengxiaoguang2014302580390
 *
 */
public class LogIn extends Authenticator {
	/**
	 * 用户名和密码
	 */
	private String name;
	private String password;
	/**
	 * 构造函数
	 * @param n  传入用户名
	 * @param pw 传入密码
	 */
	LogIn(String n,String pw){
		name=n;
		password=pw;
	}
	/**
	 * 
	 * @return name 获取用户名
	 */
	public String getName(){
		return name;
	}
	/**
	 * 用户密码认证
	 */
	public PasswordAuthentication getPasswordAuthentication(){
		return new PasswordAuthentication(name, password);
	}

	public static void main(String[] args) {
		

	}

}
