package iss.java.mail;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Sender2014302580390 {
	/**
	 * 发送账户名和密码
	 */
	private String from;
	private String password;
	LogIn login;
	Properties pro;
	Session sess;
	/**
	 * 
	 * @param sn 设置发送账户名
	 */
    public void setSenderName(String sn){
		from=sn;
	}
    /**
     * 
     * @param pw 密码
     */
	public void setPassword(String pw){
		password=pw;
	}
	/**
	 * 
	 * @return from 获取发送账户名
	 */
	public String getSenderName(){
		return from;
	}
	public String getPassword(){
		return password;
	}
	/**
	 * 建立连接
	 */
	public void connect(){//建立连接
		String S =from;
        int n =S.indexOf('@');
        int m=S.length() ;
        String server =S.substring(n+1,m);
		//建立邮件会话
		pro=new Properties();
		pro.put("mail.smtp.host","smtp."+server);
        pro.put("mail.smtp.auth","true");
        login=new LogIn(getSenderName(),getPassword());
	    sess=Session.getInstance(pro,login);
        sess.setDebug(true);
	}
	/**
	 * 发送邮件
	 */
	public void send(String recipient,String subject,Object content) 
			throws MessagingException{
		//this.connect();
		MimeMessage message=new MimeMessage(sess); //新建一个消息对象
        //设置发件人
        InternetAddress from_mail=new InternetAddress(getSenderName());
        message.setFrom(from_mail);
        //设置收件人
        InternetAddress to_mail=new InternetAddress(recipient);
        message.setRecipient(Message.RecipientType.TO ,to_mail);
        message.setSubject(subject); //设置主题
        message.setText(content.toString()); //设置内容
        message.setSentDate(new Date());//设置发送时间
      
        //发送邮件
        message.saveChanges();  //保存邮件信息
        Transport transport =sess.getTransport("smtp");
        
        transport.connect();
        transport.sendMessage(message,message.getAllRecipients());
        transport.close();
        System.out.println("邮件发送成功");
    }

	public static void main(String[] args) throws MessagingException{
		/*
		Sender2014302580390 s=new Sender2014302580390();
		s.setSenderName("zxg2014302580390@163.com");
		s.setPassword("edelimwigiagokqb");
		s.send("444363021@qq.com", "2st", "content");
		*/
	
	}

}
