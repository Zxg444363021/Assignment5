package iss.java.mail;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;

public class Receiver2014302580390 {
	/**
	 * 用户名和密码
	 */
	private String from;
	private String password;
	Properties pro;
	Session sess;
	LogIn login;
	/**
	 *
	 * @param sn 设置用户名
	 */
	public void setName(String sn){
		from=sn;
	}
	/**
	 * 
	 * @param pw 设置密码
	 */
	public void setPassword(String pw){
		password=pw;
	}
	/**
	 * 
	 * @return from 获取用户名
	 */
	public String getName(){
		return from;
	}
	/**
	 * 
	 * @return 获取密码
	 */
	public String getPassword(){
		return password;
	}
	/**
	 *建立连接
	 */
	public void connect(){
		String S =getName();
        int n =S.indexOf('@');
        int m=S.length() ;
        String server =S.substring(n+1,m);
		pro=new Properties();
		pro.setProperty("mail.store.protocol", "imap");         //指定采用imap协议接收邮件
        pro.setProperty("mail.imap.host", "imap."+server);                   //指定imap服务器
		login=new LogIn(getName(),getPassword());
        sess=Session.getInstance(pro,login);
        sess.setDebug(true);
	}
	/**
	 * 新邮件监听
	 * @return 是否有新邮件
	 */
	public boolean listen() throws MessagingException{
		Store st=sess.getStore();
        st.connect();//建立与服务器的连接
        Folder f=st.getFolder("inbox");
        f.open(Folder.READ_ONLY);//打开邮件夹
        if(f.hasNewMessages()){//查看邮件夹是否有新邮件
        	f.close(false);
            st.close();
            return true;
        }
      	f.close(false);
        st.close();
        return  false;
	}
	/**
	 * 读取新邮件
	 * @return 邮件内容
	 * @throws MessagingException
	 * @throws IOException 
	 */
	public String receive() throws MessagingException, IOException{
		//this.connect();
	    Store st=sess.getStore();
        st.connect();//建立与服务器的连接
        Folder f=st.getFolder("inbox");
        f.open(Folder.READ_ONLY);//打开邮件夹
        Message[] message=f.getMessages();
       int i=message.length-1;            //获取最新邮件
       String display="收到了最新的邮件\n" +"from:"+message[i].getFrom()[0]+ "\nSubject:" + message[i].getSubject()+"\ncontent:"+message[i].getContent().toString();

        f.close(false);
        st.close();
        return display;
	}

	public static void main(String[] args) throws MessagingException {
		/*
		Receiver2014302580390 r=new Receiver2014302580390();
		r.setName("zxg2014302580390@163.com");
		r.setPassword("edelimwigiagokqb");
		r.receive();
		*/
		

	}

}
